package com.example.asus.ayojoon.ViewHolder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    public ProductViewHolder(@NonNull View itemView) {
        super(itemView);
    }

    @Override
    public void onClick(View v) {

    }
}
